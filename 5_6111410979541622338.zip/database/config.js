// ©AiiSigma

module.exports = {
  domain: "https://danzxcempe.myserverr.web.id", // Ganti sma domain panel lu dan pastiin harus *http*
  port: "3120" // Ganti Portnoy di panel network.
};